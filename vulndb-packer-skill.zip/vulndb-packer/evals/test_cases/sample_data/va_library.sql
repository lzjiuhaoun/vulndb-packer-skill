DROP TABLE IF EXISTS `va_library`;
CREATE TABLE `va_library`  (
  `va_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `va_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '漏洞名称',
  `va_time` datetime(0) NULL DEFAULT NULL COMMENT '漏洞发布时间',
  `db_type` tinyint(2) NOT NULL COMMENT '漏洞数据库类型',
  `va_type` tinyint(1) NOT NULL COMMENT '漏洞类型',
  `va_rule` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '漏洞检查规则',
  `va_check_way` tinyint(1) NULL DEFAULT NULL COMMENT '漏洞检查方式 1jdbc查询 2对比版本',
  `va_desc` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '漏洞描述',
  `va_sql` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '漏洞sql修复语句',
  `va_level` tinyint(1) NOT NULL COMMENT '漏洞级别',
  `va_verify` tinyint(1) NULL DEFAULT NULL COMMENT '漏洞校验方式 1-YES_NO  2-RESULT_SET  3-PROCEDURE 4-UNIX_YES_NO',
  `va_suggest` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '漏洞修复建议',
  `va_cve` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '漏洞cve号',
  `va_cnnvd` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '漏洞cnnvd号',
  `va_db_version` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '漏洞影响的DB版本',
  `va_lib_version` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '漏洞库版本',
  `public_poc_exp` tinyint(1) NOT NULL DEFAULT 0 COMMENT '此漏洞是否有公开的poc或exp，0代表无，1代表有',
  PRIMARY KEY (`va_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '漏洞库信息表' ROW_FORMAT = Dynamic;
-- 数据插入SQL，一条数据一个insert语句
INSERT INTO `va_library` VALUES (1, 'CVE-2024-1234', '2024-01-15 10:30:00', 1, 1, 'check_rule_1', 1, 'MySQL权限提升漏洞', 'ALTER USER root IDENTIFIED BY new_password;', 3, 1, '建议升级MySQL到最新版本', 'CVE-2024-1234', 'CNNVD-202401-1234', 'MySQL 5.7', 'V1.0.2.19', 1);
INSERT INTO `va_library` VALUES (2, 'CVE-2024-5678', '2024-02-20 14:15:00', 1, 2, 'check_rule_2', 2, 'Oracle SQL注入漏洞', 'SELECT * FROM v$version WHERE banner LIKE ''%11.2.0.4%'';', 2, 2, '建议应用Oracle补丁', 'CVE-2024-5678', 'CNNVD-202402-5678', 'Oracle 11g', 'V1.0.2.19', 1);
INSERT INTO `va_library` VALUES (3, 'CVE-2024-9012', '2024-03-10 09:45:00', 2, 1, 'check_rule_3', 1, 'SQL Server权限问题', 'SELECT name FROM sys.databases WHERE is_trustworthy_on = 1;', 1, 1, '建议关闭trustworthy选项', 'CVE-2024-9012', 'CNNVD-202403-9012', 'SQL Server 2019', 'V1.0.2.19', 0);
